const express = require('express')
const bodyParser = require('body-parser');
const prodController = require('./controllers/prodController');
const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({extended:false}));

app.get('/', prodController.getAllProds);
app.get('/add', (req,res) => res.render('add'));
app.post('/add', prodController.addProd);
app.get('/edit/:id', prodController.getProdById);
app.post('/edit/:id', prodController.updateProd);
app.get('/dell/:id', prodController.getdeleteByprod);
app.post('/dell/:id', prodController.deleteProd);

app.get('/login/', (req, res) => res.render('login', {loginFalhou: false}));
app.post('/login/', prodController.loginProd);

app.listen(2000, () => {
    console.log('http://localhost:2000');

});
const db = require('../config/db');


const Prod = {
    getAllProds: (callback) => {
        console.log('prodModel.js','getAllProds')
        const sql = 'SELECT * FROM prods';
        db.query(sql, (err, results) => {
            if (err) throw err;
            callback(results);
        });
    },

    getProdById: (id, callback) => {
        const sql = 'SELECT * FROM prods WHERE id = ?';
        db.query(sql, [id], (err, result) => {
            if (err) throw err;
            callback(result[0]);
        });
    },

    addProd:( data, callback) => {
        const sql = 'INSERT INTO prods SET ?';
        db.query(sql, data, (err, result) => {
            if (err) throw err;
            callback(result);
        });
    },

    updateProd: (id, data, callback) => {
        const sql = 'UPDATE prods SET ? WHERE id = ?';
        db.query(sql,[data, id], (err, result) => {
            if (err) throw err;
            callback(result);
        });
    },

    deleteProd: (id,callback) => {
        const sql = 'DELETE FROM prods WHERE id = ?';
        db.query(sql,[id], (err, result) => {
            if (err) throw err;
            callback(result);
        });
    }, 

    getprodByProdname: (prodname, callback) => {
        const sql = 'SELECT * FROM prods WHERE prodname = ?';
        db.query(sql, [prodname], (err, result) => {
            if (err) throw err;
            callback(result[0]);
        })
    }
};

module.exports = Prod;

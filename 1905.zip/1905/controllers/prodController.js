const prod = require('../models/prodModel');

exports.getAllProds = (req, res) => {
     prod.getAllProds((prods) => {
         res.render('index', {prods});
     });
};

exports.getProdById = (req, res) => {
    const prodId = req.params.id;
    prod.getProdById(prodId, (prod) =>{
        res.render('edit', {prod});
    });
};

exports.getdeleteByprod = (req, res) => {
    const prodId = req.params.id;
    prod.getProdById(prodId, (prod) =>{
        res.render('dell', { prod });
    });
};

exports.addProd = (req, res) => {
    const newprod = {
        nome: req.body.nome,
        descricao: req.body.descricao,
        preco : req.body.preco,
        categoria : req.body.categoria
    };
    prod.addProd(newprod, () => {
        res.redirect('/');
    });
};

exports.updateProd = (req, res) => {
    const prodId = req.params.id;
    const updatedProd = {
        nome: req.body.nome,
        descricao: req.body.descricao,
        preco : req.body.valor,
        categoria : req.body.categoria
    };
    prod.updateProd(prodId, updatedProd, () => {
        res.redirect('/');
    });
};

exports.deleteProd = (req, res) => {
    const prodId = req.params.id;
    prod.deleteProd(prodId, () => {
        res.redirect('/');
    });
};

exports.loginProd = (req, res) => {
    const { prodname, password} = req.body;
    prod.getprodByProdname(prodname, (prod) => {
        if (prod && prod.pass === password) {
            res.redirect('/')
        } else {
            res.render('login', { loginFalhou: true });
        }
    })
};